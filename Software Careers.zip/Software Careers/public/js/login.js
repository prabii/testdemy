var x = document.getElementById("form");
x.addEventListener('submit',logged);

function logged(){
    alert("You have succesfully logged in.");
}


var y = document.getElementsByID("form");
y.addEventListener('form',submitted);

function submitted(){
    alert("You have succesfully registered.");
    
}