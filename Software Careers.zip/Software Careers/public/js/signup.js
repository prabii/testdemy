var y = document.getElementsByID("form");
y.addEventListener('form',submitted);

function submitted(){
    alert("You have succesfully registered.");   
}